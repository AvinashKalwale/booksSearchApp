import React from 'react'

function Card(props) {
  return (
    <div>{props.cards}</div>
  )
}

export default Card